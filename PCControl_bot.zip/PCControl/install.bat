@echo off
title PC Control - Установщик
color 0A
chcp 65001 >nul
echo.
echo  ╔════════════════════════════════════════╗
echo  ║        PC Control - Установщик        ║
echo  ╚════════════════════════════════════════╝
echo.
echo  [1/5] Проверяю Python...

python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo  [!] Python не найден. Скачиваю Python 3.11...
    powershell -Command "Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.11.9/python-3.11.9-amd64.exe' -OutFile 'python_setup.exe' -UseBasicParsing"
    echo  [*] Устанавливаю Python...
    start /wait python_setup.exe /quiet InstallAllUsers=1 PrependPath=1 Include_test=0
    del python_setup.exe
    echo  [+] Python установлен!
) else (
    echo  [+] Python уже установлен
)

echo.
echo  [2/5] Устанавливаю библиотеки...
pip install python-telegram-bot pyautogui psutil Pillow keyboard pyinstaller --quiet --disable-pip-version-check
echo  [+] Библиотеки установлены!

echo.
echo  [3/5] Собираю exe...
pyinstaller --onefile --noconsole --name PCControl bot.py --distpath . >nul 2>&1
if exist PCControl.exe (
    echo  [+] PCControl.exe собран!
) else (
    echo  [!] Не удалось собрать exe, буду запускать bot.py напрямую
)

echo.
echo  [4/5] Добавляю в автозагрузку Windows...
set STARTUP_DIR=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup
if exist PCControl.exe (
    copy /Y PCControl.exe "%STARTUP_DIR%\PCControl.exe" >nul
    echo  [+] PCControl.exe добавлен в автозагрузку
) else (
    set RUN_PATH=%~dp0bot.py
    echo @echo off > "%STARTUP_DIR%\PCControl.bat"
    echo start /B pythonw "%RUN_PATH%" >> "%STARTUP_DIR%\PCControl.bat"
    echo  [+] Автозапуск добавлен через bat
)

echo.
echo  [5/5] Запускаю бота...
if exist PCControl.exe (
    start "" PCControl.exe
) else (
    start "" pythonw bot.py
)

echo.
echo  ╔════════════════════════════════════════╗
echo  ║            Готово! Всё работает        ║
echo  ╚════════════════════════════════════════╝
echo.
echo  Бот запущен в фоне.
echo  Открой Telegram и напиши /start своему боту.
echo  При первом запуске бот пришлёт APK для Android.
echo.
pause
