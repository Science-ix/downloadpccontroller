# -*- coding: utf-8 -*-
import os
import sys
import json
import subprocess
import ctypes
import platform
import asyncio
import webbrowser
from datetime import datetime, timedelta
from io import BytesIO

import pyautogui
from PIL import Image
import psutil

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    ApplicationBuilder,
    CommandHandler,
    ContextTypes,
    CallbackQueryHandler,
    MessageHandler,
    filters,
    JobQueue
)

# ────────────────────────────────────────────────
# НАСТРОЙКИ — ИЗМЕНИ ЭТИ ЗНАЧЕНИЯ
# ────────────────────────────────────────────────

TOKEN = "8546436065:AAFWh1g2cfuZ--pQRTe9qgeEeqw4BJx0V9g"  # ← твой токен

TOKEN2 = ""  # ← токен второго бота для ответов в приложении (необязательно)
APP_PORT = 8765  # ← порт для приёма команд из приложения

# Храним ID сообщений для удаления
_bot2_messages = []  # [(chat_id, message_id)]
_bot1_messages = []  # [(chat_id, message_id)]

async def reply2(context, text=None, photo=None, document=None, caption=None):
    """Дублирует ответ через второй бот если TOKEN2 задан."""
    if not TOKEN2:
        return
    try:
        from telegram import Bot as TGBot
        bot2 = TGBot(token=TOKEN2)
        if photo:
            msg = await bot2.send_photo(chat_id=OWNER_CHAT_ID, photo=photo, caption=caption or "")
        elif document:
            msg = await bot2.send_document(chat_id=OWNER_CHAT_ID, document=document, caption=caption or "")
        elif text:
            msg = await bot2.send_message(chat_id=OWNER_CHAT_ID, text=text)
        else:
            return
        _bot2_messages.append((OWNER_CHAT_ID, msg.message_id))
    except Exception as e:
        print(f"reply2 error: {e}")

ALLOWED_USER_IDS = {7321839741}  # ← твой Telegram ID

OWNER_CHAT_ID = 7321839741  # ← твой chat_id

LAST_ONLINE_FILE = "last_online.txt"

BOT_START_TIME = datetime.now()

# Состояния ожидания ввода
WAITING_URL = set()
WAITING_SAY = set()
WAITING_LAUNCH_APP = set()
WAITING_VOLUME = set()
WAITING_ADD_PATH = set()
WAITING_TYPE_TEXT = set()

CHANGELOG = """
📦 *Последнее обновление*

🆕 *Добавлено:*
• Кнопка 🚀 Запустить приложение — введи имя exe и он запустится
• Кнопка 🖥️ Развернуть всё — разворачивает все свёрнутые окна
• Кнопка 🔄 Перезагрузка — перезагружает ПК через 10 сек
• Кнопка 🌐 Открыть сайт — просто отправь ссылку после нажатия
• Кнопка 🗣️ Говорить — отправь текст после нажатия, ПК произнесёт
• Кнопка 📋 Процессы — показывает только приложения с окном, без системного мусора
• Команда /help — список всех команд с описанием

🔧 *Исправлено:*
• Убраны кнопки Chrome/Telegram/Steam — заменены на универсальный запуск
• Закрыть всё — теперь через psutil, реально закрывает только запущенное
• Свернуть все окна — Shell.Application с timeout, работает быстро
• Закрытие процессов — мягкое завершение без принудительного убийства
• Список процессов — только реальные приложения с окном
"""

HELP_TEXT = """
📖 *Список всех команд*

🖥️ *Управление приложениями:*
/launch — запустить приложение по имени exe
/open [ссылка] — открыть сайт в браузере
/processes — список приложений (нажми чтобы закрыть)
/close browsers — закрыть все браузеры
/close messengers — закрыть мессенджеры
/allclose — закрыть браузеры и мессенджеры

🖥️ *Управление ПК:*
/screen — скриншот экрана
/minimize — свернуть все окна
/lock — заблокировать ПК
/reboot — перезагрузить ПК через 10 сек
/off — выключить ПК через 10 сек

🗑️ *Корзина:*
/bin — открыть корзину
/clearbin — очистить корзину

🔊 *Звук:*
/say [текст] — произнести текст вслух

📊 *Инфо:*
/status — статус ПК (аптайм, ОС, CPU)
/wake — проверить онлайн ли бот
/help — это сообщение

💡 *Совет:* все команды доступны через кнопки меню /start
"""

# ────────────────────────────────────────────────

def allowed(update: Update) -> bool:
    if update.effective_user is None:
        return False
    uid = update.effective_user.id
    # Разрешаем владельцу и самому боту (команды из приложения)
    return uid in ALLOWED_USER_IDS or update.effective_user.is_bot

# ──────────────────────────────────────────────── Last Online ────────────────────────────────────────────────

def update_last_online():
    try:
        with open(LAST_ONLINE_FILE, "w", encoding="utf-8") as f:
            f.write(datetime.now().isoformat())
    except Exception as e:
        print(f"Ошибка записи last_online: {e}")

async def update_last_online_callback(context: ContextTypes.DEFAULT_TYPE):
    update_last_online()

async def get_last_online_str():
    if not os.path.exists(LAST_ONLINE_FILE):
        return "Первый запуск! 🆕"
    try:
        with open(LAST_ONLINE_FILE, "r", encoding="utf-8") as f:
            last_str = f.read().strip()
        last_time = datetime.fromisoformat(last_str)
        delta = datetime.now() - last_time
        if delta.total_seconds() < 300:
            return "Только что онлайн 🟢"
        hours = delta.seconds // 3600
        minutes = (delta.seconds % 3600) // 60
        days = delta.days
        parts = []
        if days: parts.append(f"{days} дн.")
        if hours: parts.append(f"{hours} ч.")
        if minutes: parts.append(f"{minutes} мин.")
        ago = " ".join(parts) if parts else "менее минуты"
        return f"Был онлайн {ago} назад 🔴"
    except Exception as e:
        print(f"Ошибка чтения last_online: {e}")
        return "Ошибка чтения времени ⚠️"

# ──────────────────────────────────────────────── Главное меню ────────────────────────────────────────────────

def main_menu_keyboard():
    keyboard = [
        [
            InlineKeyboardButton("🚀 Запустить приложение", callback_data="cmd_launch_app"),
        ],
        [
            InlineKeyboardButton("📸 Скриншот",    callback_data="cmd_screen"),
            InlineKeyboardButton("📊 Статус",      callback_data="cmd_status"),
            InlineKeyboardButton("😄 Пинг",        callback_data="cmd_wake"),
        ],
        [
            InlineKeyboardButton("🗑️ Корзина",     callback_data="cmd_bin"),
            InlineKeyboardButton("🧹 Очист.корзину", callback_data="cmd_clearbin"),
        ],
        [
            InlineKeyboardButton("🖥️ Свернуть всё",  callback_data="cmd_minimize"),
            InlineKeyboardButton("🖥️ Развернуть всё", callback_data="cmd_maximize"),
        ],
        [
            InlineKeyboardButton("🔒 Блокировка",   callback_data="cmd_lock"),
        ],
        [
            InlineKeyboardButton("🌐 Закрыть браузеры",    callback_data="cmd_close_browsers"),
            InlineKeyboardButton("💬 Закрыть мессенджеры", callback_data="cmd_close_messengers"),
        ],
        [
            InlineKeyboardButton("❌ Закрыть всё",  callback_data="cmd_allclose"),
            InlineKeyboardButton("📋 Процессы",     callback_data="cmd_processes"),
        ],
        [
            InlineKeyboardButton("🌐 Открыть сайт", callback_data="cmd_open_url"),
            InlineKeyboardButton("🗣️ Говорить",     callback_data="cmd_say"),
        ],
        [
            InlineKeyboardButton("⌨️ Напечатать текст", callback_data="cmd_type_text"),
            InlineKeyboardButton("💤 Сон",               callback_data="cmd_sleep"),
        ],
        [
            InlineKeyboardButton("🌐 Браузер", callback_data="cmd_browser"),
        ],
        [
            InlineKeyboardButton("🔄 Перезагрузка", callback_data="cmd_reboot"),
            InlineKeyboardButton("🔴 Выключить ПК", callback_data="cmd_off"),
        ],
        [
            InlineKeyboardButton("📋 Последнее обновление", callback_data="cmd_changelog"),
            InlineKeyboardButton("⚠️ Проблемы",             callback_data="cmd_problems"),
        ],
    ]
    return InlineKeyboardMarkup(keyboard)

async def menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not allowed(update): return
    await update.message.reply_text(
        "🖥️ *Управление ПК*\nВыбери действие:",
        reply_markup=main_menu_keyboard(),
        parse_mode="Markdown"
    )

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not allowed(update): return
    await update.message.reply_text(
        "🖥️ *Управление ПК*\nВыбери действие:",
        reply_markup=main_menu_keyboard(),
        parse_mode="Markdown"
    )

# ──────────────────────────────────────────────── Команды ────────────────────────────────────────────────

PATHS_FILE = "paths.json"

def load_paths() -> dict:
    if os.path.exists(PATHS_FILE):
        try:
            with open(PATHS_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except:
            pass
    return {}

def save_paths(paths: dict):
    with open(PATHS_FILE, "w", encoding="utf-8") as f:
        json.dump(paths, f, ensure_ascii=False, indent=2)

SEARCH_DIRS = [
    os.environ.get("ProgramFiles", r"C:\Program Files"),
    os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"),
    os.environ.get("LOCALAPPDATA", ""),
    os.environ.get("APPDATA", ""),
    r"C:\Windows\System32",
]

def find_exe(name: str) -> str | None:
    """Ищет exe по имени в стандартных папках."""
    if not name.lower().endswith(".exe"):
        name += ".exe"
    # Сначала проверяем сохранённые пути
    paths = load_paths()
    for label, path in paths.items():
        if os.path.basename(path).lower() == name.lower():
            return path
    # Ищем в стандартных папках
    for base in SEARCH_DIRS:
        if not base:
            continue
        for root, dirs, files in os.walk(base):
            for f in files:
                if f.lower() == name.lower():
                    return os.path.join(root, f)
    return None

def launch_program(app_input: str) -> tuple[bool, str]:
    """Запускает программу. Возвращает (успех, сообщение)."""
    app_input = app_input.strip().strip('"').strip("'")
    # Полный путь — запускаем напрямую
    if os.path.isabs(app_input) and os.path.exists(app_input):
        subprocess.Popen(app_input, creationflags=subprocess.CREATE_NO_WINDOW)
        return True, app_input
    # Имя exe — ищем
    found = find_exe(app_input)
    if found:
        subprocess.Popen(found, creationflags=subprocess.CREATE_NO_WINDOW)
        return True, found
    # Последняя попытка через shell
    try:
        subprocess.Popen(app_input, shell=True, creationflags=subprocess.CREATE_NO_WINDOW)
        return True, app_input
    except Exception as e:
        return False, str(e).encode('utf-8', errors='replace').decode('utf-8')

async def launch_app_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not allowed(update): return
    if not context.args:
        await update.message.reply_text(
            "Пример:\n"
            "/launch telegram.exe\n"
            "/launch C:\\Games\\game.exe"
        )
        return
    app_input = " ".join(context.args).strip()
    ok, msg = launch_program(app_input)
    if ok:
        await update.message.reply_text(f"🚀 Запускаю: {os.path.basename(msg)}")
    else:
        await update.message.reply_text(
            f"❌ Не найдено: {app_input}\n\n"
            f"Добавь путь через кнопку 🚀 Запустить приложение → Мои программы → Добавить"
        )

async def recycle(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not allowed(update): return
    try:
        subprocess.Popen("explorer.exe shell:RecycleBinFolder")
        await update.message.reply_text("Открываю корзину 🗑️")
    except Exception as e:
        await update.message.reply_text(f"Ошибка: {e}")

async def clearbin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not allowed(update): return
    try:
        os.system('powershell -Command "Clear-RecycleBin -Force -ErrorAction SilentlyContinue"')
        await update.message.reply_text("Корзина очищена 🧹")
    except Exception as e:
        await update.message.reply_text(f"Ошибка: {e}")

async def off(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not allowed(update): return
    await update.message.reply_text("Выключаю ПК через 10 секунд... 🔴")
    try:
        await context.bot.send_message(OWNER_CHAT_ID, "🔴 Компьютер выключается")
    except:
        pass
    os.system("shutdown /s /t 10")

async def reboot(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not allowed(update): return
    await update.message.reply_text("Перезагружаю ПК через 10 секунд... 🔄")
    try:
        await context.bot.send_message(OWNER_CHAT_ID, "🔄 Компьютер перезагружается")
    except:
        pass
    os.system("shutdown /r /t 10")

async def lock(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not allowed(update): return
    try:
        ctypes.windll.user32.LockWorkStation()
        await update.message.reply_text("Компьютер заблокирован 🔒")
    except Exception as e:
        await update.message.reply_text(f"Ошибка: {e}")

async def minimize(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not allowed(update): return
    try:
        ctypes.windll.user32.ShowWindow(ctypes.windll.user32.GetShellWindow(), 0)
        subprocess.run(
            ["powershell", "-NoProfile", "-Command",
             "(New-Object -ComObject Shell.Application).MinimizeAll()"],
            creationflags=subprocess.CREATE_NO_WINDOW,
            timeout=3
        )
        await update.message.reply_text("Все окна свёрнуты 🖥️➡️📂")
    except Exception as e:
        await update.message.reply_text(f"Не получилось свернуть: {str(e)}")

async def maximize(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not allowed(update): return
    try:
        subprocess.run(
            ["powershell", "-NoProfile", "-Command",
             "(New-Object -ComObject Shell.Application).UndoMinimizeALL()"],
            creationflags=subprocess.CREATE_NO_WINDOW,
            timeout=3
        )
        await update.message.reply_text("Все окна развёрнуты 🖥️")
    except Exception as e:
        await update.message.reply_text(f"Ошибка: {str(e)}")

async def screen(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not allowed(update): return
    try:
        msg = await update.message.reply_text("Делаю скриншот... 📸")
        await asyncio.sleep(1.2)
        screenshot = pyautogui.screenshot()
        bio = BytesIO()
        bio.name = f"screen_{datetime.now():%Y-%m-%d_%H-%M-%S}.png"
        screenshot.save(bio, format="PNG")
        bio.seek(0)
        await context.bot.send_photo(
            chat_id=update.effective_chat.id,
            photo=bio,
            caption="Скриншот экрана 📱"
        )
        await msg.delete()
    except Exception as e:
        await update.message.reply_text(f"Ошибка: {e}")

async def say(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not allowed(update): return
    if not context.args:
        await update.message.reply_text("Пример: /say Привет как дела 🎤")
        return
    text = " ".join(context.args)
    try:
        ps = f'''
        Add-Type -AssemblyName System.Speech
        $s = New-Object System.Speech.Synthesis.SpeechSynthesizer
        $s.SelectVoice("Microsoft Irina Desktop")
        $s.Speak("{text.replace('"', '""')}")
        '''
        with open("say_temp.ps1", "w", encoding="utf-8") as f:
            f.write(ps)
        subprocess.Popen(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", "say_temp.ps1"])
        await update.message.reply_text(f"Говорю: {text} 🗣️")
    except Exception as e:
        await update.message.reply_text(f"Ошибка: {e}")

def get_condition(percent):
    if percent < 50:   return "Отлично 🟢"
    if percent < 75:   return "Норм 🟡"
    if percent < 90:   return "Высокая 🟠"
    return "Критично 🔴"

def get_temp_condition(temp):
    if temp is None:   return "Нет данных"
    if temp < 50:      return f"{temp:.0f}°C 🟢 Холодный"
    if temp < 70:      return f"{temp:.0f}°C 🟡 Тёплый"
    if temp < 85:      return f"{temp:.0f}°C 🟠 Горячий"
    return f"{temp:.0f}°C 🔴 Перегрев!"

def get_cpu_temp_windows():
    """Получает температуру CPU через WMI (MSAcpi) — работает на Windows без доп. программ."""
    try:
        import wmi
        w = wmi.WMI(namespace="root\\wmi")
        temps = []
        for zone in w.MSAcpi_ThermalZoneTemperature():
            t = (zone.CurrentTemperature / 10.0) - 273.15
            if 0 < t < 120:
                temps.append(t)
        if temps:
            return max(temps)
    except:
        pass
    return None

def get_status_text(uptime_str, last_online_text):
    uname = platform.uname()

    # CPU название
    cpu_name = platform.processor()
    for junk in ["(R)", "(TM)", "  "]:
        cpu_name = cpu_name.replace(junk, "")
    cpu_name = cpu_name.strip()[:40]

    # CPU нагрузка и частота
    cpu_load = psutil.cpu_percent(interval=1)
    cpu_freq = psutil.cpu_freq()
    cpu_freq_str = f"{cpu_freq.current:.0f} МГц" if cpu_freq else "Н/Д"

    # CPU температура (Windows)
    cpu_temp = get_cpu_temp_windows()

    # RAM
    ram = psutil.virtual_memory()
    ram_used = ram.used / (1024**3)
    ram_total = ram.total / (1024**3)

    # Диски
    disks_lines = []
    for part in psutil.disk_partitions():
        try:
            if 'cdrom' in part.opts or part.fstype == '':
                continue
            usage = psutil.disk_usage(part.mountpoint)
            used = usage.used / (1024**3)
            total = usage.total / (1024**3)
            letter = part.device[:2]
            disks_lines.append(
                f"    💽 {letter}  {used:.1f} / {total:.1f} ГБ — {get_condition(usage.percent)}"
            )
        except:
            continue
    disks_str = "\n".join(disks_lines) if disks_lines else "    Нет данных"

    # GPU через nvidia-smi (NVIDIA)
    gpu_block = ""
    try:
        r = subprocess.run(
            ["nvidia-smi", "--query-gpu=name,utilization.gpu,temperature.gpu,memory.used,memory.total",
             "--format=csv,noheader,nounits"],
            capture_output=True, text=True, timeout=3,
            creationflags=subprocess.CREATE_NO_WINDOW
        )
        if r.returncode == 0 and r.stdout.strip():
            parts = r.stdout.strip().split(",")
            gpu_name = parts[0].strip()[:35]
            gpu_load = float(parts[1].strip())
            gpu_temp = float(parts[2].strip())
            gpu_mem_used = float(parts[3].strip()) / 1024
            gpu_mem_total = float(parts[4].strip()) / 1024
            gpu_block = (
                f"🎮 *Видеокарта*\n"
                f"    {gpu_name}\n"
                f"    Нагрузка: {gpu_load:.0f}% — {get_condition(gpu_load)}\n"
                f"    Температура: {get_temp_condition(gpu_temp)}\n"
                f"    Память: {gpu_mem_used:.1f} / {gpu_mem_total:.1f} ГБ\n\n"
            )
    except:
        pass

    # Если NVIDIA не нашли — берём название GPU через WMI (без температуры, AMD/Intel не дают через стандартный WMI)
    if not gpu_block:
        try:
            import wmi
            w = wmi.WMI()
            gpus = w.Win32_VideoController()
            if gpus:
                gpu_name = gpus[0].Name[:35] if gpus[0].Name else "Неизвестно"
                gpu_block = (
                    f"🎮 *Видеокарта*\n"
                    f"    {gpu_name}\n"
                    f"    Температура: Нет данных\n\n"
                )
        except:
            gpu_block = "🎮 *Видеокарта*\n    Нет данных\n\n"

    text = (
        f"🖥️ *Состояние ПК* 📊\n"
        f"🕐 Работает: {uptime_str}\n"
        f"{last_online_text}\n\n"

        f"⚙️ *Процессор*\n"
        f"    {cpu_name}\n"
        f"    Нагрузка: {cpu_load:.0f}% — {get_condition(cpu_load)}\n"
        f"    Частота: {cpu_freq_str}\n"
        f"    Температура: {get_temp_condition(cpu_temp)}\n\n"

        + gpu_block +

        f"💾 *Оперативная память*\n"
        f"    {ram_used:.1f} / {ram_total:.1f} ГБ — {get_condition(ram.percent)}\n\n"

        f"💿 *Диски*\n"
        f"{disks_str}\n\n"

        f"🖥️ {uname.node}  •  {uname.system} {uname.release}"
    )
    return text

async def status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not allowed(update): return
    uptime = datetime.now() - BOT_START_TIME
    uptime_str = str(uptime).split('.')[0]
    last_online_text = await get_last_online_str()
    text = get_status_text(uptime_str, last_online_text)
    await update.message.reply_text(text, parse_mode="Markdown")

async def wake(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not allowed(update): return
    await update.message.reply_text("Я уже здесь 😄")

async def processes_json(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not allowed(update): return
    proc_list = get_user_apps()[:30]
    data = [{"pid": pid, "name": name.replace(".exe", "")} for pid, name in proc_list]
    await update.message.reply_text(f"PROCS_JSON:{json.dumps(data, ensure_ascii=False)}")

async def sleep_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not allowed(update): return
    await update.message.reply_text("💤 Ухожу в сон...")
    subprocess.run(
        ["powershell", "-NoProfile", "-Command",
         "Add-Type -AssemblyName System.Windows.Forms; "
         "[System.Windows.Forms.Application]::SetSuspendState('Suspend', $false, $false)"],
        creationflags=subprocess.CREATE_NO_WINDOW, timeout=5
    )

async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not allowed(update): return
    await update.message.reply_text(HELP_TEXT, parse_mode="Markdown")

async def close(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not allowed(update): return
    arg = " ".join(context.args).lower().strip() if context.args else ""
    if not arg:
        await update.message.reply_text(
            "Выбери:\n"
            "/close browsers     — браузеры\n"
            "/close messengers   — Telegram, Discord и т.д."
        )
        return
    if "browser" in arg:
        programs = ["chrome.exe", "msedge.exe", "firefox.exe", "opera.exe", "brave.exe"]
        action = "браузеры"
    elif "messenger" in arg or "chat" in arg:
        programs = ["telegram.exe", "discord.exe", "whatsapp.exe", "signal.exe"]
        action = "мессенджеры"
    else:
        await update.message.reply_text("Неизвестно. Используй browsers или messengers")
        return
    await update.message.reply_text(f"Закрываю {action}...")
    killed = []
    for proc in psutil.process_iter(['pid', 'name']):
        try:
            if proc.info['name'].lower() in programs:
                proc.terminate()
                killed.append(proc.info['name'].replace(".exe", ""))
        except:
            continue
    await update.message.reply_text(f"Закрыто: {', '.join(killed)}" if killed else "Ничего не было запущено")

async def allclose(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not allowed(update): return
    await update.message.reply_text("Закрываю всё...")
    # Берём только приложения с видимым окном
    apps_with_window = {pid for pid, name in get_user_apps()}
    targets = ["chrome.exe", "msedge.exe", "firefox.exe", "opera.exe",
               "brave.exe", "telegram.exe", "discord.exe", "whatsapp.exe"]
    killed = []
    for proc in psutil.process_iter(['pid', 'name']):
        try:
            if proc.info['pid'] in apps_with_window and proc.info['name'].lower() in targets:
                proc.terminate()
                killed.append(proc.info['name'].replace(".exe", ""))
        except:
            continue
    await update.message.reply_text(f"Закрыто: {', '.join(killed)}" if killed else "Ничего не было запущено")

async def open_url(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not allowed(update): return
    if not context.args:
        await update.message.reply_text("Пришли ссылку\n/open https://youtube.com")
        return
    url = " ".join(context.args).strip().strip('"').strip("'")
    if not url.lower().startswith(("http://", "https://")):
        url = "https://" + url
    try:
        webbrowser.open_new_tab(url)
        await update.message.reply_text(f"Открываю → {url} 🌐")
    except Exception as e:
        await update.message.reply_text(f"Ошибка: {e}")

def get_user_apps():
    """Возвращает только приложения с окном — как в диспетчере задач."""
    user32 = ctypes.windll.user32
    pids_with_window = set()

    @ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_int, ctypes.c_int)
    def enum_callback(hwnd, _):
        if user32.IsWindowVisible(hwnd) and user32.GetWindow(hwnd, 4) == 0:
            pid = ctypes.c_ulong()
            user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
            if pid.value:
                pids_with_window.add(pid.value)
        return True

    user32.EnumWindows(enum_callback, 0)
    apps = []
    for proc in psutil.process_iter(['pid', 'name']):
        try:
            if proc.info['pid'] in pids_with_window:
                apps.append((proc.info['pid'], proc.info['name']))
        except:
            continue
    apps.sort(key=lambda x: x[1].lower())
    return apps

async def processes(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not allowed(update): return
    proc_list = get_user_apps()[:30]
    if not proc_list:
        await update.message.reply_text("Нет запущенных приложений")
        return
    keyboard = []
    for pid, name in proc_list:
        clean = name.replace(".exe", "")
        keyboard.append([
            InlineKeyboardButton(f"🔵 {clean}", callback_data="noop"),
            InlineKeyboardButton("🗕 Свернуть", callback_data=f"min_proc_{pid}"),
            InlineKeyboardButton("✖️ Закрыть",  callback_data=f"close_proc_{pid}"),
        ])
    keyboard.append([InlineKeyboardButton("◀️ Назад", callback_data="cmd_back")])
    await update.message.reply_text(
        "🖥️ *Запущенные приложения:*",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="Markdown"
    )

# ──────────────────────────────────────────────── Обработчик кнопок ────────────────────────────────────────────────

async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data = query.data

    if data == "noop":
        return

    elif data == "cmd_launch_app":
        paths = load_paths()
        keyboard = []
        for label, path in paths.items():
            keyboard.append([InlineKeyboardButton(f"🚀 {label}", callback_data=f"launch_saved_{label}")])
        keyboard.append([InlineKeyboardButton("✏️ Ввести вручную", callback_data="launch_manual")])
        keyboard.append([InlineKeyboardButton("➕ Добавить программу", callback_data="launch_add")])
        if paths:
            keyboard.append([InlineKeyboardButton("🗑️ Удалить программу", callback_data="launch_delete_list")])
        keyboard.append([InlineKeyboardButton("◀️ Назад", callback_data="cmd_back")])
        await query.edit_message_text(
            "🚀 *Запустить приложение*\n\nВыбери из списка или введи вручную:",
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )

    elif data == "launch_manual":
        WAITING_LAUNCH_APP.add(query.message.chat_id)
        await query.edit_message_text(
            "✏️ Введи имя или полный путь:\n\n"
            "Примеры:\n"
            "• telegram.exe\n"
            "• C:\\Games\\game.exe\n\n"
            "Напиши *отмена* чтобы вернуться назад.",
            parse_mode="Markdown"
        )

    elif data == "launch_add":
        WAITING_ADD_PATH.add(query.message.chat_id)
        await query.edit_message_text(
            "➕ Отправь путь к программе:\n\n"
            "Вариант 1 — с названием:\nTelegram | C:\\Users\\User\\AppData\\Roaming\\Telegram Desktop\\Telegram.exe\n\n"
            "Вариант 2 — просто путь:\nC:\\Users\\User\\AppData\\Roaming\\Telegram Desktop\\Telegram.exe\n\n"
            "Напиши *отмена* чтобы вернуться назад.",
            parse_mode="Markdown"
        )

    elif data == "launch_delete_list":
        paths = load_paths()
        keyboard = []
        for label in paths:
            keyboard.append([InlineKeyboardButton(f"🗑️ {label}", callback_data=f"launch_del_{label}")])
        keyboard.append([InlineKeyboardButton("◀️ Назад", callback_data="cmd_launch_app")])
        await query.edit_message_text(
            "🗑️ *Выбери программу для удаления:*",
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )

    elif data.startswith("launch_del_"):
        label = data[len("launch_del_"):]
        paths = load_paths()
        if label in paths:
            del paths[label]
            save_paths(paths)
            await query.answer(f"✅ {label} удалён", show_alert=False)
        # Возвращаемся в меню запуска
        keyboard = []
        for lbl, path in paths.items():
            keyboard.append([InlineKeyboardButton(f"🚀 {lbl}", callback_data=f"launch_saved_{lbl}")])
        keyboard.append([InlineKeyboardButton("✏️ Ввести вручную", callback_data="launch_manual")])
        keyboard.append([InlineKeyboardButton("➕ Добавить программу", callback_data="launch_add")])
        if paths:
            keyboard.append([InlineKeyboardButton("🗑️ Удалить программу", callback_data="launch_delete_list")])
        keyboard.append([InlineKeyboardButton("◀️ Назад", callback_data="cmd_back")])
        await query.edit_message_text(
            "🚀 *Запустить приложение*\n\nВыбери из списка или введи вручную:",
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )

    elif data.startswith("launch_saved_"):
        label = data[len("launch_saved_"):]
        paths = load_paths()
        path = paths.get(label, "")
        if path:
            ok, msg = launch_program(path)
            if ok:
                await query.edit_message_text(f"🚀 Запускаю: *{label}*", parse_mode="Markdown", reply_markup=main_menu_keyboard())
            else:
                await query.edit_message_text(f"❌ Ошибка запуска: {msg}", reply_markup=main_menu_keyboard())
        else:
            await query.edit_message_text("❌ Путь не найден", reply_markup=main_menu_keyboard())

    elif data == "cmd_screen":
        await query.edit_message_text("Делаю скриншот... 📸")
        await asyncio.sleep(1.2)
        try:
            screenshot = pyautogui.screenshot()
            bio = BytesIO()
            bio.name = f"screen_{datetime.now():%Y-%m-%d_%H-%M-%S}.png"
            screenshot.save(bio, format="PNG")
            bio.seek(0)
            bio2 = BytesIO(bio.getvalue())
            msg = await context.bot.send_photo(chat_id=query.message.chat_id, photo=bio, caption="Скриншот экрана 📱")
            _bot1_messages.append((query.message.chat_id, msg.message_id))
            await reply2(context, photo=bio2, caption="📸 Скриншот")
            await context.bot.send_message(
                chat_id=query.message.chat_id,
                text="🖥️ *Управление ПК*\nВыбери действие:",
                reply_markup=main_menu_keyboard(),
                parse_mode="Markdown"
            )
        except Exception as e:
            await context.bot.send_message(chat_id=query.message.chat_id, text=f"Ошибка скриншота: {e}", reply_markup=main_menu_keyboard())

    elif data == "cmd_status":
        uptime = datetime.now() - BOT_START_TIME
        uptime_str = str(uptime).split('.')[0]
        last_online_text = await get_last_online_str()
        text = get_status_text(uptime_str, last_online_text)
        await query.edit_message_text(text, parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("◀️ Назад", callback_data="cmd_back")]]))
        await reply2(context, text=text)

    elif data == "cmd_wake":
        await query.edit_message_text("Я уже здесь 😄",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("◀️ Назад", callback_data="cmd_back")]]))

    elif data == "cmd_bin":
        try:
            subprocess.Popen("explorer.exe shell:RecycleBinFolder")
            await query.edit_message_text("Открываю корзину 🗑️",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("◀️ Назад", callback_data="cmd_back")]]))
        except Exception as e:
            await query.edit_message_text(f"Ошибка: {e}", reply_markup=main_menu_keyboard())

    elif data == "cmd_clearbin":
        try:
            os.system('powershell -Command "Clear-RecycleBin -Force -ErrorAction SilentlyContinue"')
            await query.edit_message_text("Корзина очищена 🧹",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("◀️ Назад", callback_data="cmd_back")]]))
        except Exception as e:
            await query.edit_message_text(f"Ошибка: {e}", reply_markup=main_menu_keyboard())

    elif data == "cmd_minimize":
        try:
            ctypes.windll.user32.ShowWindow(ctypes.windll.user32.GetShellWindow(), 0)
            subprocess.run(
                ["powershell", "-NoProfile", "-Command",
                 "(New-Object -ComObject Shell.Application).MinimizeAll()"],
                creationflags=subprocess.CREATE_NO_WINDOW, timeout=3
            )
            await query.edit_message_text("Все окна свёрнуты 🖥️➡️📂",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("◀️ Назад", callback_data="cmd_back")]]))
        except Exception as e:
            await query.edit_message_text(f"Ошибка: {e}", reply_markup=main_menu_keyboard())

    elif data == "cmd_maximize":
        try:
            subprocess.run(
                ["powershell", "-NoProfile", "-Command",
                 "(New-Object -ComObject Shell.Application).UndoMinimizeALL()"],
                creationflags=subprocess.CREATE_NO_WINDOW, timeout=3
            )
            await query.edit_message_text("Все окна развёрнуты 🖥️",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("◀️ Назад", callback_data="cmd_back")]]))
        except Exception as e:
            await query.edit_message_text(f"Ошибка: {e}", reply_markup=main_menu_keyboard())

    elif data == "cmd_lock":
        try:
            ctypes.windll.user32.LockWorkStation()
            await query.edit_message_text("Компьютер заблокирован 🔒",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("◀️ Назад", callback_data="cmd_back")]]))
        except Exception as e:
            await query.edit_message_text(f"Ошибка: {e}", reply_markup=main_menu_keyboard())

    elif data == "cmd_close_browsers":
        targets = ["chrome.exe", "msedge.exe", "firefox.exe", "opera.exe", "brave.exe"]
        killed = []
        for proc in psutil.process_iter(['pid', 'name']):
            try:
                if proc.info['name'].lower() in targets:
                    proc.terminate()
                    killed.append(proc.info['name'].replace(".exe", ""))
            except:
                continue
        result = f"Закрыто: {', '.join(killed)} 🌐" if killed else "Браузеры не были запущены"
        await query.edit_message_text(result, reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("◀️ Назад", callback_data="cmd_back")]]))

    elif data == "cmd_close_messengers":
        targets = ["telegram.exe", "discord.exe", "whatsapp.exe", "signal.exe"]
        killed = []
        for proc in psutil.process_iter(['pid', 'name']):
            try:
                if proc.info['name'].lower() in targets:
                    proc.terminate()
                    killed.append(proc.info['name'].replace(".exe", ""))
            except:
                continue
        result = f"Закрыто: {', '.join(killed)} 💬" if killed else "Мессенджеры не были запущены"
        await query.edit_message_text(result, reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("◀️ Назад", callback_data="cmd_back")]]))

    elif data == "cmd_allclose":
        # Закрываем только процессы у которых есть видимое окно
        user32 = ctypes.windll.user32
        pids_with_window = set()
        @ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_int, ctypes.c_int)
        def _cb(hwnd, _):
            if user32.IsWindowVisible(hwnd):
                pid = ctypes.c_ulong()
                user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
                if pid.value:
                    pids_with_window.add(pid.value)
            return True
        user32.EnumWindows(_cb, 0)

        targets = ["chrome.exe", "msedge.exe", "firefox.exe", "opera.exe",
                   "brave.exe", "telegram.exe", "discord.exe", "whatsapp.exe"]
        killed = []
        for proc in psutil.process_iter(['pid', 'name']):
            try:
                if proc.info['name'].lower() in targets and proc.info['pid'] in pids_with_window:
                    proc.terminate()
                    killed.append(proc.info['name'].replace(".exe", ""))
            except:
                continue
        result = f"Закрыто: {', '.join(killed)} ❌" if killed else "Ничего не было запущено"
        await query.edit_message_text(result, reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("◀️ Назад", callback_data="cmd_back")]]))

    elif data == "cmd_off":
        await query.edit_message_text(
            "🔴 *Выключить ПК?*\n\nПК выключится через 10 секунд после подтверждения.",
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("✅ Да, выключить", callback_data="cmd_off_confirm")],
                [InlineKeyboardButton("❌ Отмена",        callback_data="cmd_back")],
            ])
        )

    elif data == "cmd_off_confirm":
        await query.edit_message_text("🔴 Выключаю ПК через 10 секунд...")
        try:
            await context.bot.send_message(OWNER_CHAT_ID, "🔴 Компьютер выключается")
        except:
            pass
        os.system("shutdown /s /t 10")

    elif data == "cmd_reboot":
        await query.edit_message_text(
            "🔄 *Перезагрузить ПК?*\n\nПК перезагрузится через 10 секунд после подтверждения.",
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("✅ Да, перезагрузить", callback_data="cmd_reboot_confirm")],
                [InlineKeyboardButton("❌ Отмена",            callback_data="cmd_back")],
            ])
        )

    elif data == "cmd_reboot_confirm":
        await query.edit_message_text("🔄 Перезагружаю ПК через 10 секунд...")
        try:
            await context.bot.send_message(OWNER_CHAT_ID, "🔄 Компьютер перезагружается")
        except:
            pass
        os.system("shutdown /r /t 10")

    elif data == "cmd_processes":
        proc_list = get_user_apps()[:30]
        if not proc_list:
            await query.edit_message_text("Нет запущенных приложений", reply_markup=main_menu_keyboard())
            return
        keyboard = []
        for pid, name in proc_list:
            clean = name.replace(".exe", "")
            keyboard.append([
                InlineKeyboardButton(f"🔵 {clean}", callback_data="noop"),
                InlineKeyboardButton("🗕 Свернуть", callback_data=f"min_proc_{pid}"),
                InlineKeyboardButton("✖️ Закрыть",  callback_data=f"close_proc_{pid}"),
            ])
        keyboard.append([InlineKeyboardButton("◀️ Назад", callback_data="cmd_back")])
        await query.edit_message_text(
            "🖥️ *Запущенные приложения:*",
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode="Markdown"
        )

    elif data == "cmd_open_url":
        WAITING_URL.add(query.message.chat_id)
        await query.edit_message_text("Отправь ссылку в чат (например: https://youtube.com) 🌐")

    elif data == "cmd_say":
        WAITING_SAY.add(query.message.chat_id)
        await query.edit_message_text("Отправь текст который нужно произнести 🗣️")

    elif data == "cmd_type_text":
        WAITING_TYPE_TEXT.add(query.message.chat_id)
        await query.edit_message_text(
            "⌨️ Отправь текст который нужно напечатать на ПК\n\n"
            "Напиши отмена чтобы вернуться назад."
        )

    elif data == "cmd_sleep":
        try:
            subprocess.run(
                ["powershell", "-NoProfile", "-Command",
                 "Add-Type -AssemblyName System.Windows.Forms; "
                 "[System.Windows.Forms.Application]::SetSuspendState('Suspend', $false, $false)"],
                creationflags=subprocess.CREATE_NO_WINDOW, timeout=5
            )
            await query.edit_message_text("💤 ПК уходит в спящий режим...",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("◀️ Назад", callback_data="cmd_back")]]))
        except Exception as e:
            await query.edit_message_text(f"Ошибка: {e}", reply_markup=main_menu_keyboard())

    elif data == "cmd_browser":
        await query.edit_message_text(
            "🌐 *Управление браузером*",
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup([
                [
                    InlineKeyboardButton("◀️ Назад",   callback_data="browser_back"),
                    InlineKeyboardButton("🔄 Обновить", callback_data="browser_refresh"),
                    InlineKeyboardButton("▶️ Вперёд",  callback_data="browser_forward"),
                ],
                [InlineKeyboardButton("◀️ В меню", callback_data="cmd_back")],
            ])
        )

    elif data == "browser_back":
        pyautogui.hotkey("alt", "left")
        await query.answer("◀️ Назад", show_alert=False)

    elif data == "browser_forward":
        pyautogui.hotkey("alt", "right")
        await query.answer("▶️ Вперёд", show_alert=False)

    elif data == "browser_refresh":
        pyautogui.hotkey("f5")
        await query.answer("🔄 Обновлено", show_alert=False)

    elif data == "type_backspace":
        try:
            import keyboard
            keyboard.press_and_release("backspace")
        except:
            pyautogui.press("backspace")
        await query.answer("⌫ Стёрто", show_alert=False)

    elif data == "type_cancel":
        WAITING_TYPE_TEXT.discard(query.message.chat_id)
        await query.edit_message_text("❌ Режим печати выключен", reply_markup=main_menu_keyboard())

    elif data == "cmd_back":
        await query.edit_message_text(
            "🖥️ *Управление ПК*\nВыбери действие:",
            reply_markup=main_menu_keyboard(),
            parse_mode="Markdown"
        )

    elif data == "cmd_problems":
        await query.edit_message_text(
            "⚠️ *Известные проблемы*\n\n"

            "🌡️ *Температура CPU*\n"
            "    Не работает без стороннего ПО\n"
            "    Нужен OpenHardwareMonitor\n"
            "    запущенный от администратора\n\n"

            "🎮 *Температура/нагрузка GPU*\n"
            "    NVIDIA — работает ✅\n"
            "    AMD/Intel — нужен OpenHardwareMonitor\n\n"

            "🗕 *Свернуть процесс*\n"
            "    Работает не для всех приложений\n"
            "    Некоторые игры игнорируют команду\n\n"

            "🔊 *Говорить (TTS)*\n"
            "    Голос Microsoft Irina Desktop\n"
            "    может отсутствовать на некоторых ПК\n"
            "    Установи русский языковой пакет Windows\n\n"

            "📋 *Процессы*\n"
            "    Показывает макс. 30 приложений\n\n"

            "🔵 *Всё остальное работает на Windows без доп. установок* ✅",
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("◀️ Назад", callback_data="cmd_back")]])
        )

    elif data == "cmd_changelog":
        await query.edit_message_text(
            CHANGELOG,
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("◀️ Назад", callback_data="cmd_back")]])
        )

    elif data.startswith("min_proc_"):
        try:
            pid = int(data.split("_")[2])
            import ctypes as ct
            user32 = ct.windll.user32
            # Находим окно по PID и сворачиваем
            SW_MINIMIZE = 6
            result = []
            @ct.WINFUNCTYPE(ct.c_bool, ct.c_int, ct.c_int)
            def cb(hwnd, _):
                p = ct.c_ulong()
                user32.GetWindowThreadProcessId(hwnd, ct.byref(p))
                if p.value == pid and user32.IsWindowVisible(hwnd):
                    user32.ShowWindow(hwnd, SW_MINIMIZE)
                    result.append(hwnd)
                return True
            user32.EnumWindows(cb, 0)
            proc = psutil.Process(pid)
            await query.answer(f"🗕 {proc.name().replace('.exe','')} свёрнут", show_alert=False)
        except Exception as e:
            await query.answer(f"Ошибка: {str(e)}", show_alert=True)

    elif data.startswith("close_proc_"):
        try:
            pid = int(data.split("_")[2])
            p = psutil.Process(pid)
            name = p.name()
            p.terminate()
            await query.edit_message_text(f"{name} (PID {pid}) закрыт ✅", reply_markup=main_menu_keyboard())
        except psutil.NoSuchProcess:
            await query.edit_message_text("Процесс уже завершён ✅", reply_markup=main_menu_keyboard())
        except psutil.AccessDenied:
            await query.edit_message_text("Нет прав закрыть этот процесс ⛔", reply_markup=main_menu_keyboard())
        except Exception as e:
            await query.edit_message_text(f"Ошибка: {str(e)}", reply_markup=main_menu_keyboard())

    else:
        await query.edit_message_text("Неизвестная команда", reply_markup=main_menu_keyboard())

# ──────────────────────────────────────────────── Обработчик текстовых сообщений ────────────────────────────────────────────────

async def text_message_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not allowed(update): return
    chat_id = update.effective_chat.id
    text = update.message.text.strip()

    # Обработка команд из мобильного приложения (__cb__КОМАНДА)
    if text.startswith("__cb__"):
        cmd = text[6:]
        if cmd == "type_backspace":
            try:
                import keyboard as kb
                kb.press_and_release("backspace")
            except:
                pyautogui.press("backspace")
            await update.message.reply_text("⌫ Стёрто")
        elif cmd == "type_cancel":
            WAITING_TYPE_TEXT.discard(chat_id)
            await update.message.reply_text("❌ Режим печати выключен", reply_markup=main_menu_keyboard())
        elif cmd == "browser_back":
            pyautogui.hotkey("alt", "left")
            await update.message.reply_text("◀️ Назад")
        elif cmd == "browser_forward":
            pyautogui.hotkey("alt", "right")
            await update.message.reply_text("▶️ Вперёд")
        elif cmd == "browser_refresh":
            pyautogui.hotkey("f5")
            await update.message.reply_text("🔄 Обновлено")
        elif cmd == "browser_close_tab":
            pyautogui.hotkey("ctrl", "w")
            await update.message.reply_text("✖️ Вкладка закрыта")
        elif cmd == "browser_fullscreen":
            pyautogui.press("f11")
            await update.message.reply_text("⛶ Полный экран")
        elif cmd == "browser_video_fullscreen":
            pyautogui.press("f")
            await update.message.reply_text("🎬 F — полный экран видео")
        elif cmd == "browser_scroll_down":
            pyautogui.press("space")
            await update.message.reply_text("⬇️ Прокрутил вниз")
        elif cmd == "browser_scroll_up":
            pyautogui.hotkey("shift", "space")
            await update.message.reply_text("⬆️ Прокрутил вверх")
        return

    # Отмена любого ожидания
    if text.lower() in ["отмена", "/cancel", "cancel"]:
        WAITING_ADD_PATH.discard(chat_id)
        WAITING_LAUNCH_APP.discard(chat_id)
        WAITING_URL.discard(chat_id)
        WAITING_SAY.discard(chat_id)
        await update.message.reply_text("❌ Отменено", reply_markup=main_menu_keyboard())
        return

    if chat_id in WAITING_TYPE_TEXT:
        try:
            import keyboard
            for i, word in enumerate(text.split()):
                keyboard.write(word, delay=0.05)
                if i < len(text.split()) - 1:
                    keyboard.press_and_release("space")
        except Exception as e:
            await update.message.reply_text(f"Ошибка: {e}", reply_markup=main_menu_keyboard())
            return
        await update.message.reply_text(
            f"⌨️ Напечатано: {text}",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("⌫ Стереть", callback_data="type_backspace")],
                [InlineKeyboardButton("❌ Отмена",  callback_data="type_cancel")],
            ])
        )
        return

    if chat_id in WAITING_ADD_PATH:
        WAITING_ADD_PATH.discard(chat_id)
        # Принимаем как с | так и просто путь
        if "|" in text:
            parts = text.split("|", 1)
            label = parts[0].strip()
            path = parts[1].strip().strip('"').strip("'")
        else:
            # Если просто путь — берём имя файла как название
            path = text.strip().strip('"').strip("'")
            label = os.path.splitext(os.path.basename(path))[0]
        if not label or not path:
            await update.message.reply_text(
                "❌ Не понял. Отправь в формате:\nTelegram | C:\\путь\\Telegram.exe\n\nИли просто путь:\nC:\\путь\\Telegram.exe",
                parse_mode="Markdown",
                reply_markup=main_menu_keyboard()
            )
            return
        paths = load_paths()
        paths[label] = path
        save_paths(paths)
        await update.message.reply_text(
            f"✅ Сохранено!\n🚀 *{label}*\n{path}",
            parse_mode="Markdown",
            reply_markup=main_menu_keyboard()
        )
        return

    if chat_id in WAITING_LAUNCH_APP:
        WAITING_LAUNCH_APP.discard(chat_id)
        app_input = text.strip('"').strip("'")
        ok, msg = launch_program(app_input)
        if ok:
            await update.message.reply_text(f"🚀 Запускаю: *{os.path.basename(msg)}*", parse_mode="Markdown", reply_markup=main_menu_keyboard())
        else:
            await update.message.reply_text(
                f"❌ Не найдено: {app_input}\n\nДобавь путь через ➕ Добавить программу",
                parse_mode="Markdown",
                reply_markup=main_menu_keyboard()
            )
        return

    if chat_id in WAITING_URL:
        WAITING_URL.discard(chat_id)
        url = text.strip('"').strip("'")
        if not url.lower().startswith(("http://", "https://")):
            url = "https://" + url
        try:
            webbrowser.open_new_tab(url)
            await update.message.reply_text(f"Открываю → {url} 🌐", reply_markup=main_menu_keyboard())
        except Exception as e:
            await update.message.reply_text(f"Ошибка: {e}", reply_markup=main_menu_keyboard())
        return

    if chat_id in WAITING_SAY:
        WAITING_SAY.discard(chat_id)
        try:
            ps = f'''
        Add-Type -AssemblyName System.Speech
        $s = New-Object System.Speech.Synthesis.SpeechSynthesizer
        $s.SelectVoice("Microsoft Irina Desktop")
        $s.Speak("{text.replace('"', '""')}")
        '''
            with open("say_temp.ps1", "w", encoding="utf-8") as f:
                f.write(ps)
            subprocess.Popen(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", "say_temp.ps1"])
            await update.message.reply_text(f"Говорю: {text} 🗣️", reply_markup=main_menu_keyboard())
        except Exception as e:
            await update.message.reply_text(f"Ошибка: {e}", reply_markup=main_menu_keyboard())
        return

# ──────────────────────────────────────────────── Запуск ────────────────────────────────────────────────

async def send_startup_notification(app):
    try:
        await app.bot.send_message(
            chat_id=OWNER_CHAT_ID,
            text=f"🟢 Компьютер включился! 🚀\nВремя: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        )
    except Exception as e:
        print(f"Не удалось отправить уведомление: {e}")


FIRST_RUN_FILE = "first_run.txt"
APK_FILE_ID = "BQACAgIAAxkBAAICw2m26N_6NXkCXovOP8ry5JeZxyAXAAKBnwACMim5ScvsEeqdEF6UOgQ"

async def send_apk_on_first_run(app):
    """Отправляет APK пользователю при первом запуске."""
    if os.path.exists(FIRST_RUN_FILE):
        return
    try:
        # Помечаем что первый запуск уже был
        with open(FIRST_RUN_FILE, "w") as f:
            f.write("done")
        if APK_FILE_ID:
            await app.bot.send_message(
                chat_id=OWNER_CHAT_ID,
                text="📱 Бот запущен впервые! Держи APK для Android:"
            )
            await app.bot.send_document(
                chat_id=OWNER_CHAT_ID,
                document=APK_FILE_ID,
                filename="PCControl.apk",
                caption="🖥️ PC Control для Android. Установи и введи токен в настройках."
            )
    except Exception as e:
        print(f"Ошибка отправки APK: {e}")


async def on_startup(app):
    await send_startup_notification(app)
    await send_apk_on_first_run(app)

async def send_shutdown_notification(app):
    try:
        await app.bot.send_message(
            chat_id=OWNER_CHAT_ID,
            text="🔴 Бот выключен с ПК 💤\nУправление недоступно до следующего запуска."
        )
    except:
        pass

async def cleanup_history(context: ContextTypes.DEFAULT_TYPE):
    """Удаляет все накопленные сообщения обоих ботов."""
    # Чистим бот 1
    global _bot1_messages
    for chat_id, msg_id in _bot1_messages:
        try:
            await context.bot.delete_message(chat_id=chat_id, message_id=msg_id)
        except:
            pass
    _bot1_messages.clear()

    # Чистим бот 2
    global _bot2_messages
    if TOKEN2:
        try:
            from telegram import Bot as TGBot
            bot2 = TGBot(token=TOKEN2)
            for chat_id, msg_id in _bot2_messages:
                try:
                    await bot2.delete_message(chat_id=chat_id, message_id=msg_id)
                except:
                    pass
        except:
            pass
    _bot2_messages.clear()

async def poll_bot2():
    """Читает команды из второго бота и выполняет их."""
    if not TOKEN2:
        return
    from telegram import Bot as TGBot
    bot2 = TGBot(token=TOKEN2)
    offset = 0
    print("Второй бот запущен, слушаю команды из приложения...")
    while True:
        try:
            updates = await bot2.get_updates(offset=offset, timeout=10, limit=10)
            for upd in updates:
                offset = upd.update_id + 1
                text = upd.message.text.strip() if upd.message and upd.message.text else ""
                if not text:
                    continue
                print(f"Команда из приложения: {text}")
                await handle_app_command(text)
        except Exception as e:
            if "Conflict" not in str(e):
                print(f"poll_bot2 error: {e}")
        await asyncio.sleep(1)

async def handle_app_command(text: str):
    """Выполняет команду полученную из приложения."""
    from telegram import Bot as TGBot
    main_bot = TGBot(token=TOKEN)

    async def reply(msg):
        if TOKEN2:
            try:
                bot2 = TGBot(token=TOKEN2)
                await bot2.send_message(chat_id=OWNER_CHAT_ID, text=msg)
            except:
                pass

    # Обрабатываем __cb__ команды
    if text.startswith("__cb__"):
        cmd = text[6:]
        if cmd == "browser_back":
            pyautogui.hotkey("alt", "left")
            await reply("◀️ Назад")
        elif cmd == "browser_forward":
            pyautogui.hotkey("alt", "right")
            await reply("▶️ Вперёд")
        elif cmd == "browser_refresh":
            pyautogui.hotkey("f5")
            await reply("🔄 Обновлено")
        elif cmd == "browser_close_tab":
            pyautogui.hotkey("ctrl", "w")
            await reply("✖️ Вкладка закрыта")
        elif cmd == "browser_fullscreen":
            pyautogui.press("f11")
            await reply("⛶ Полный экран")
        elif cmd == "browser_video_fullscreen":
            pyautogui.press("f")
            await reply("🎬 Полный экран видео")
        elif cmd == "browser_scroll_down":
            pyautogui.press("space")
            await reply("⬇️ Прокрутил вниз")
        elif cmd == "browser_scroll_up":
            pyautogui.hotkey("shift", "space")
            await reply("⬆️ Прокрутил вверх")
        elif cmd == "type_backspace":
            pyautogui.press("backspace")
            await reply("⌫ Стёрто")
        return

    # Обычные команды
    if text == "/screen":
        try:
            await asyncio.sleep(0.5)
            screenshot = pyautogui.screenshot()
            bio = BytesIO()
            screenshot.save(bio, format="PNG")
            bio.seek(0)
            if TOKEN2:
                bot2 = TGBot(token=TOKEN2)
                await bot2.send_photo(chat_id=OWNER_CHAT_ID, photo=bio, caption="📸 Скриншот")
        except Exception as e:
            await reply(f"Ошибка скриншота: {e}")
    elif text == "/status":
        uptime = datetime.now() - BOT_START_TIME
        uptime_str = str(uptime).split('.')[0]
        t = get_status_text(uptime_str, "")
        await reply(t)
    elif text == "/wake":
        await reply("😄 Я здесь!")
    elif text == "/minimize":
        subprocess.run(["powershell", "-NoProfile", "-Command", "(New-Object -ComObject Shell.Application).MinimizeAll()"], creationflags=subprocess.CREATE_NO_WINDOW, timeout=3)
        await reply("🖥️ Всё свёрнуто")
    elif text == "/maximize":
        subprocess.run(["powershell", "-NoProfile", "-Command", "(New-Object -ComObject Shell.Application).UndoMinimizeALL()"], creationflags=subprocess.CREATE_NO_WINDOW, timeout=3)
        await reply("🖥️ Всё развёрнуто")
    elif text == "/lock":
        ctypes.windll.user32.LockWorkStation()
        await reply("🔒 Заблокировано")
    elif text == "/bin":
        subprocess.Popen("explorer.exe shell:RecycleBinFolder")
        await reply("🗑️ Открываю корзину")
    elif text == "/clearbin":
        os.system('powershell -Command "Clear-RecycleBin -Force -ErrorAction SilentlyContinue"')
        await reply("🧹 Корзина очищена")
    elif text == "/sleep":
        await reply("💤 Сон...")
        subprocess.run(["powershell", "-NoProfile", "-Command", "Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.Application]::SetSuspendState('Suspend', $false, $false)"], creationflags=subprocess.CREATE_NO_WINDOW, timeout=5)
    elif text == "/reboot":
        await reply("🔄 Перезагрузка через 10 сек...")
        os.system("shutdown /r /t 10")
    elif text == "/off":
        await reply("🔴 Выключение через 10 сек...")
        os.system("shutdown /s /t 10")
    elif text.startswith("/open "):
        url = text[6:].strip()
        webbrowser.open_new_tab(url)
        await reply(f"🌐 Открываю {url}")
    elif text.startswith("/launch "):
        app_input = text[8:].strip()
        ok, msg = launch_program(app_input)
        await reply(f"🚀 Запущено: {msg}" if ok else f"❌ Не найдено: {app_input}")
    elif text.startswith("/say "):
        say_text = text[5:].strip()
        ps = f'Add-Type -AssemblyName System.Speech; $s = New-Object System.Speech.Synthesis.SpeechSynthesizer; $s.SelectVoice("Microsoft Irina Desktop"); $s.Speak("{say_text}")'
        subprocess.Popen(["powershell", "-NoProfile", "-Command", ps], creationflags=subprocess.CREATE_NO_WINDOW)
        await reply(f"🗣️ Говорю: {say_text}")
    elif text.startswith("/close "):
        arg = text[7:].lower()
        if "browser" in arg:
            targets = ["chrome.exe", "msedge.exe", "firefox.exe", "opera.exe", "brave.exe"]
        else:
            targets = ["telegram.exe", "discord.exe", "whatsapp.exe", "signal.exe"]
        killed = []
        for proc in psutil.process_iter(['name']):
            try:
                if proc.info['name'].lower() in targets:
                    proc.terminate()
                    killed.append(proc.info['name'].replace(".exe",""))
            except: pass
        await reply(f"✅ Закрыто: {', '.join(killed)}" if killed else "Ничего не запущено")
    elif text == "/allclose":
        targets = ["chrome.exe","msedge.exe","firefox.exe","opera.exe","brave.exe","telegram.exe","discord.exe","whatsapp.exe"]
        killed = []
        for proc in psutil.process_iter(['name']):
            try:
                if proc.info['name'].lower() in targets:
                    proc.terminate()
                    killed.append(proc.info['name'].replace(".exe",""))
            except: pass
        await reply(f"✅ Закрыто: {', '.join(killed)}" if killed else "Ничего не запущено")
    elif text == "/processes":
        procs = get_user_apps()[:20]
        names = [name.replace(".exe","") for _, name in procs]
        await reply("📋 Процессы:\n" + "\n".join(f"• {n}" for n in names))

async def error_handler(update, context):
    err = str(context.error)
    if "Conflict" in err or "terminated by other" in err:
        return  # Игнорируем конфликт с приложением
    print(f"Ошибка: {err}")

def main():
    app = (
        ApplicationBuilder()
        .token(TOKEN)
        .post_init(on_startup)
        .post_shutdown(send_shutdown_notification)
        .build()
    )

    cmds = {
        "start":     start,
        "menu":      menu,
        "launch":    launch_app_cmd,
        "bin":       recycle,
        "clearbin":  clearbin,
        "off":       off,
        "reboot":    reboot,
        "lock":      lock,
        "minimize":  minimize,
        "maximize":  maximize,
        "screen":    screen,
        "say":       say,
        "status":    status,
        "wake":      wake,
        "help":      help_cmd,
        "close":     close,
        "allclose":  allclose,
        "open":      open_url,
        "processes": processes,
        "processes_json": processes_json,
        "sleep":     sleep_cmd,
    }

    for cmd, func in cmds.items():
        app.add_handler(CommandHandler(cmd, func))

    app.add_handler(CallbackQueryHandler(button_handler))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, text_message_handler))
    app.add_error_handler(error_handler)

    # Запускаем второй бот для приёма команд из приложения
    if TOKEN2:
        import threading
        def run_bot2():
            import asyncio
            asyncio.run(poll_bot2())
        t = threading.Thread(target=run_bot2, daemon=True)
        t.start()

    app.job_queue.run_repeating(
        callback=update_last_online_callback,
        interval=300,
        first=10
    )

    app.job_queue.run_repeating(
        callback=cleanup_history,
        interval=60,
        first=60
    )

    print("Бот запущен...")
    app.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    # Скрываем окно консоли если запущен как exe
    if sys.platform == "win32":
        ctypes.windll.user32.ShowWindow(ctypes.windll.kernel32.GetConsoleWindow(), 0)
    main()
